package com.capg.service;

import java.util.List;
import com.capg.bean.AccountDet;
import com.capg.bean.Transaction;
import com.capg.dao.BankDaoClas;
import com.capg.dao.BankDaoIntrface;

public class BankServiceClass implements BankServiceIntrface

{

	BankDaoIntrface dao = new BankDaoClas();

	@Override
	public long insertAccount(AccountDet account) {
		long accNum = dao.insertAccount(account);
		return accNum;

	}

	@Override
	public AccountDet retrieveAccount(Long acc) {

		AccountDet bnks = dao.retriveAccount(acc);
		return bnks;
	}

	@Override
	public AccountDet depositMoney(Long accno2, Long depositAmt) {
		return dao.depositMoney(accno2, depositAmt);

	}

	@Override
	public AccountDet withdrawMoney(Long accno3, Long withdrawAmt) {
		return dao.withdrawMoney(accno3, withdrawAmt);

	}

	@Override
	public AccountDet transfer(Long sender, Long receiver, Long amt) {
		// TODO Auto-generated method stub
		return dao.transfer(sender, receiver, amt);
	}

	@Override
	public List<Transaction> printTransaction() {
		return dao.printTransaction();
	}

	@Override
	public boolean nameValidation(String userName) {
	    if(userName.matches("[A-Z][a-z A-z]*"))
            return true;
            else
            return false;
	}

	@Override
	public boolean mobNotValid(long mob) {
	    String mobile=Long.toString(mob);
        if(mobile.matches("[4-9][0-9]{9}"))
            return true;
        else
            return false;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean accountTypeValidation(String acType) {
		 if (acType.equalsIgnoreCase("savings") || acType.equalsIgnoreCase("current") )
	            return true;
	            else
	            return false;
		// TODO Auto-generated method stub
	
	}

	
	}


