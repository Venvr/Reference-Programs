package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BankDao;
import com.cg.dao.BankDao2;
import com.cg.entity.BankEntity;
import com.cg.entity.TransactionEntity;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankDao bankDao;

	@Autowired
	BankDao2 bankDao2;

	public List<BankEntity> createAccount(BankEntity bank) {
		bankDao.save(bank);
		return bankDao.findAll();
	}

	public BankEntity accountsDetails(Long accNo) {
		return bankDao.findById(accNo).get();
	}

	public Double showBalance(Long accNo) {
		Double bal = bankDao.findById(accNo).get().getBal();
		return bal;
	}

	public Double deposit(Long accNo, Double amt) {

		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			BankEntity tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Deposite", bank.get().getBal(),
					bank.get().getBal() + amt);
			bankDao2.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}
	}

	public Double withdraw(Long accNo, Double amt) {
		Optional<BankEntity> bank = bankDao.findById(accNo);
		if (bank.isPresent()) {
			BankEntity tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() - amt);
			bankDao.save(tempEntity);
			TransactionEntity trans = new TransactionEntity(accNo, "Withdraw", bank.get().getBal(),
					bank.get().getBal() - amt);
			bankDao2.save(trans);
			return showBalance(accNo);
		} else {
			return showBalance(accNo);
		}
	}

	public Double fundTransfer(Long accNo1, Double amt, Long accNo2) {
		Optional<BankEntity> bank1 = bankDao.findById(accNo1);
		Optional<BankEntity> bank2 = bankDao.findById(accNo2);
		if (bank1.isPresent() && bank2.isPresent()) {
			BankEntity tempEntity = bank1.get();
			tempEntity.setBal(bank1.get().getBal() - amt);
			bankDao.save(tempEntity);
			BankEntity tempEntity2 = bank2.get();
			tempEntity2.setBal(bank2.get().getBal() + amt);
			bankDao.save(tempEntity2);
			TransactionEntity trans = new TransactionEntity(accNo1, "Fund Transfer", bank1.get().getBal(),
					bank1.get().getBal() - amt);
			bankDao2.save(trans);
			TransactionEntity trans2 = new TransactionEntity(accNo2, "Fund Recieved", bank2.get().getBal(),
					amt + bank2.get().getBal());
			bankDao2.save(trans2);
			return showBalance(accNo1);
		} else {
			return showBalance(accNo1);
		}
	}

	public List<TransactionEntity> printTransaction(Long accNo) {

		return   bankDao2.printTransaction(accNo);
	}
}
