package com.capg.service;

import java.util.List;

import com.capg.bean.AccountDet;
import com.capg.bean.Transaction;

public interface BankServiceIntrface {
	long insertAccount(AccountDet account);

	AccountDet retrieveAccount(Long acc);

	AccountDet depositMoney(Long accno2, Long depositAmt);

	AccountDet withdrawMoney(Long accno3, Long withdrawAmt);

	AccountDet transfer(Long sender, Long receiver, Long amt);

	List<Transaction> printTransaction();

	boolean nameValidation(String userName);

	boolean mobNotValid(long mob);

	boolean accountTypeValidation(String acType);

	
}
