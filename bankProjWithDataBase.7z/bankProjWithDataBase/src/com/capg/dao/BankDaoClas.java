package com.capg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cap.usrdefExptns.AccountNotFound;
import com.capg.bean.AccountDet;
import com.capg.bean.Transaction;

public class BankDaoClas implements BankDaoIntrface

{

	Map<Long, AccountDet> bnk = new HashMap<Long, AccountDet>(); //stores key and value data 
	Map<Transaction, Long> bnknew = new HashMap<Transaction, Long>();//stores key and value data for transactions

	@Override
	public long insertAccount(AccountDet account) {
		bnk.put(account.getAcno(), account);
		return account.getAcno();

	}

	@Override
	public AccountDet retriveAccount(Long acc) {

		AccountDet bnks = bnk.get(acc);
		if(bnks == null)
		{
			throw new AccountNotFound("Enter Valid Account Number:");
		
		}
		return bnks;
	}

	@Override
	public AccountDet depositMoney(Long acc2, Long depositAmt) {
		AccountDet b3 = bnk.get(acc2);
		if(b3 == null)
		{
			throw new AccountNotFound("Enter Valid Account Number:");
		
		}
		long bal2 = b3.getBalance();
		Long bal3 = bal2 + depositAmt;
		b3.setBalance(bal3);

		Transaction t = new Transaction();
		t.setNewBal(bal3);
		t.setOldBal(bal2);
		t.setFrmAc(acc2);
		t.setTransid(1000);
		t.setTransType("Deposit");
		bnknew.put(t, acc2);

		return b3;
	}

	@Override
	public AccountDet withdrawMoney(Long accno3, Long withdrawAmt) {
		AccountDet b4 = bnk.get(accno3);
		if(b4 == null)
		{
			throw new AccountNotFound("Enter Valid Account Number:");
		
		}
		long bal5 = b4.getBalance();
		long bal6 = bal5 - withdrawAmt;
		b4.setBalance(bal6);

		Transaction t = new Transaction();
		t.setNewBal(bal6);
		t.setOldBal(bal5);
		t.setToAc(accno3);
		t.setTransid(1000);
		t.setTransType("Withdraw");
		bnknew.put(t, accno3);

		return b4;

	}

	@Override
	public AccountDet transfer(Long sender, Long receiver, Long amt) {
		AccountDet b4 = bnk.get(sender);
		if(b4 == null)
		{
			throw new AccountNotFound("Enter Valid Account Number:");
		
		}
		long bal5 = b4.getBalance();
		AccountDet b5 = bnk.get(receiver);
		if(b5 == null)
		{
			throw new AccountNotFound("Enter Valid Account Number:");
		
		}
		long bal6 = b5.getBalance();
		
		bal5 = bal5 - amt;
		bal6 = bal6 + amt;
		b4.setBalance(bal5);
		b5.setBalance(bal6);

		if(bal5<amt)
        {
            System.out.println("INSUFFICIENT BALANCE!!!");
        }
        else
        {
            System.out.println("-------------TRANSFER SUCCESSFULL---------------");
        }
		
		Transaction t = new Transaction();
		t.setNewBal(bal6);
		t.setOldBal(bal5);
		t.setToAc(receiver);
		t.setFrmAc(sender);
		t.setTransid(1000);
		t.setTransType("Fund Transfer");
		bnknew.put(t, receiver);

		return b5;
	}

	@Override
	public List<Transaction> printTransaction() {
		List<Transaction> List = new ArrayList<Transaction>(bnknew.keySet());
		return List;
	}

}
