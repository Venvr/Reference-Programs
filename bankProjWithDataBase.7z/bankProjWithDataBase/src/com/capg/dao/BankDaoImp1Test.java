package com.capg.dao;

import org.junit.Assert;
import org.junit.Test;

import com.capg.bean.AccountDet;


public class BankDaoImp1Test
{
    //positive response
    BankDaoClas dao=new BankDaoClas();
   /* @Test
    public void createAcc_1()
    {
        AccountDet bank=new AccountDet();
        bank.setAcno((long) 1000);
        bank.setBranch("basavanagudi");
        bank.setAcType("savings");
        bank.setPhoneNo((long) 989899898);
        bank.setName("qwerty");
        long AccNum=dao.insertAccount(bank);
        
        Assert.assertEquals(1000,AccNum);
        
    }*/
	
   //negative response
        @Test
        public void createAcc_2()
        {
            AccountDet bank=new AccountDet();
            bank.setAcno((long) 1000);
            bank.setBranch("basavanagudi");
            bank.setAcType("savings");
            bank.setPhoneNo((long) 989899898);
            bank.setName("qwerty");
            long AccNum=dao.insertAccount(bank);
            
            Assert.assertEquals(10000,AccNum);
            
        }
} 




