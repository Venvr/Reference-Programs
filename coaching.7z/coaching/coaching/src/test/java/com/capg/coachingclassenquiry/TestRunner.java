package com.capg.coachingclassenquiry;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {
		"pretty" }, features = "C:\\Users\\cv4\\OneDrive - Capgemini\\Desktop\\parveen\\test\\coaching\\src\\test\\resources\\coachingClassEnquiry\\coachingClassEnquiry.feature", glue = "com.capg.coachingclassenquiry")
public class TestRunner {

}