package src.com.capg.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import src.com.cap.usrdefExptns.AccountNotFoundException;
import src.com.capg.bean.Account;
import src.com.capg.bean.Transaction;
import src.com.capg.service.BankService;
import src.com.capg.service.BankServiceImpl;

public class MainUi {
	static BankService service = new BankServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			System.out.println("Welcome to Bank Application"); //
			System.out.println("==============================");
			System.out.println("1. Create Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transaction");
			System.out.println("Enter your Choice");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				try {
					String custName;
					long custNum;
					String accType;
					boolean accTypeValid = false;
					boolean isOkName = false;

					do {
						System.out.println("Enter Name :  ");
						custName = scanner.next();
						isOkName = service.custNameOk(custName); // Method for customer name validation
																	

						if (!isOkName) {
							System.out.println("Please enter Alphabets only");
						}
					} while (!isOkName);
					boolean isOkNum;
					do {
						System.out.println("Enter the Contact Number : ");
						custNum = scanner.nextLong();
						isOkNum = service.custNumOk(custNum);// Method for mobile number validation
																
						if (!isOkNum) {
							System.out.println("Please enter Correct Mobile Number");
						}
					} while (!isOkNum);

					System.out.println("Enter the Branch Name : ");
					String branchName = scanner.next();

					do {
						System.out.println("Enter the Account Type : ");
						accType = scanner.next();
						accTypeValid = service.accountTypeValidation(accType); // Method for account type validation
																				

						if (!accTypeValid) {
							System.out.println("Enter Valid Account Type \n saving or current");
						}
					} while (!accTypeValid);

					System.out.println("Enter the Opening Balance : ");
					long balance = scanner.nextLong();

					Account account = new Account();

					account.setAccType(accType);
					account.setBalance(balance);
					account.setBranchName(branchName);
					account.setCustName(custName);
					account.setCustNum(custNum);
					long acc = service.createAccount(account);
					System.out.println("---------------Account created successfully-----------  ");
					System.out.println(" Your Account Number is :" + acc);
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}

				break;

			case 2:
				try {
					System.out.println("Enter the Account Number : ");
					long accNo1 = scanner.nextLong();
					long balance = service.accountBalance(accNo1);
					System.out.println("Account Balance is : " + balance);

				} catch (InputMismatchException ae) {
					// System.out.println(ae.getMessage());
					System.out.println("Input Type Mismatch");
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 3:
				try {
					System.out.println("Enter the Account Number : ");
					long accNo1 = scanner.nextLong();
					System.out.println("Enter the Amount to be Deposited : ");
					long depAmt = scanner.nextLong();
					long a = service.depositAmt(accNo1, depAmt);
					System.out.println("Available Balance : " + a);
					System.out.println("---------------Amount Deposited successfully-----------");
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 4:
				try {
					System.out.println("Enter the Account Number : ");
					long accNo1 = scanner.nextLong();
					System.out.println("Enter the Amount to be WithDrawn : ");
					long withAmt = scanner.nextLong();
					service.withdrawAmt(accNo1, withAmt);
					System.out.println("Available Balance :" + service.accountBalance(accNo1));
					System.out.println("---------------Amount Withdrawn successfully-----------");
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 5:
				try {
					System.out.println("Enter the Sender Account number");
					long accNo1 = scanner.nextLong();
					System.out.println("Enter the receiver Account number");
					long accNo2 = scanner.nextLong();
					System.out.println("Enter the Amount to transfer");
					long amt = scanner.nextLong();
					service.transfer(accNo1, accNo2, amt);
					System.out.println("--------------Amount Transferred Succesfully-------------");
					System.out.println("Balance in Sender Account : " + service.accountBalance(accNo1));
					System.out.println("Balance in Receiver Account : " + service.accountBalance(accNo2));
				} catch (AccountNotFoundException e) {
					System.out.println(e.getMessage());
				}

				break;
			case 6:
				
					System.out.println("Transactions :");	
					List<Transaction> list1=service.printTransactions();
					for(Transaction tran:list1){
			            System.out.println("Transaction Id:"+tran.getTransId()+"     From Account:"+tran.getFromAccount()+"      To Account:"+tran.getToAccount()+"      Old Balance:"+tran.getOldBalance()+"      New Balance:"+tran.getNewBalance()+"      Transaction Type:"+tran.getTransactionType());
			        }
									

				
				break;
			case 7:
				try {
					System.out.println("Thank You");
					System.exit(0);
				} catch (Exception e) {
					System.out.println("Enter Valid information");
				}
				break;
			default:
				System.out.println("Wrong Choice!!!!!!");
				break;
			}
		}
	}
}
