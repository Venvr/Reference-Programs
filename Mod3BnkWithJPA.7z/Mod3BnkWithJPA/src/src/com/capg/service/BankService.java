package src.com.capg.service;

import java.util.List;

import src.com.capg.bean.Account;
import src.com.capg.bean.Transaction;

public interface BankService {
long createAccount(Account account);
long accountBalance(Long accNo1);
long depositAmt(long accNo1, long depAmt);
long withdrawAmt(long accNo1, long withAmt);
long transfer(long accNo1, long accNo2, long amt);
List<Transaction> printTransactions();
boolean custNameOk(String custName);
boolean custNumOk(long custNum);
boolean accountTypeValidation(String accType);
}