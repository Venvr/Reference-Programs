package src.com.capg.service;

import java.util.List;

import src.com.capg.bean.Account;
import src.com.capg.bean.Transaction;
import src.com.capg.dao.BankDao;
import src.com.capg.dao.BankDaoImpl;


public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoImpl();

	@Override
	public long createAccount(Account account) {
		dao.beginTransaction();
		long acNum=dao.createAccount(account); 
		dao.commitTransaction();
		return acNum;
	}

	@Override
	public long accountBalance(Long accNo1) {		
		//dao.beginTransaction();
		long balance=dao.accountBalance(accNo1);
		//dao.commitTransaction();
		return balance;

	}

	@Override
	public long depositAmt(long accNo1, long depAmt) {
		dao.beginTransaction();
		long balance= dao.depositAmt(accNo1, depAmt);
		dao.commitTransaction();
		return balance;
	}

	@Override
	public long withdrawAmt(long accNo1, long withAmt) {
		dao.beginTransaction();
		long balance= dao.withdrawAmt(accNo1, withAmt);
		dao.commitTransaction();
		return balance;
	}

	@Override
	public long transfer(long accNo1, long accNo2, long amt) {
		dao.beginTransaction();
		long balance=dao.transfer(accNo1, accNo2, amt);
		dao.commitTransaction();
		return balance;
	}

	
	@Override
	public List<Transaction> printTransactions() {
		//dao.beginTransaction();
		List<Transaction> list1=dao.printTransactions();
		//dao.commitTransaction();
		return list1;
	}


	@Override
	public boolean custNameOk(String custName) {
		// TODO Auto-generated method stub
		if(custName.matches("[A-Z][a-z A-z]*"))
		{
        return true;
		}
        else
        {
        	return false;
        }
           
       
	}

	@Override
	public boolean custNumOk(long custNum) {
		String custNum1=Long.toString(custNum);
		if(custNum1.matches("[6-9][0-9]{9}"))
		{
        return true;
		}
        else
        {
        	return false;
        }
	}

	@Override
	public boolean accountTypeValidation(String accType) {
		  if (accType.equalsIgnoreCase("saving") || accType.equalsIgnoreCase("current") )
		  {
	            return true;
		  }
		  else{
		return false;
		  }
	}

	

	

}
