package src.com.capg.dao;

import org.junit.Assert;
import org.junit.Test;

import src.com.capg.bean.Account;


public class BankDaoImp1Test
{
    //positive response
    BankDaoImpl dao=new BankDaoImpl();
    
  /*  @Test
    public void createAcc_1()
    {
        Account bank=new Account();
        bank.setAccNo((long) 42);
        bank.setBranchName("basavanagudi");
        bank.setAccType("savings");
        bank.setCustNum((long) 989899898);
        bank.setCustName("qwerty");
        long AccNum=dao.createAccount(bank);
        
        Assert.assertEquals(1000,AccNum);
        
    }*/
    //negative response
        @Test
        public void createAcc_2()        
        {
	        Account bank=new Account();
	        bank.setAccNo((long) 1000);
	        bank.setBranchName("basavanagudi");
	        bank.setAccType("savings");
	        bank.setCustNum((long) 989899898);
	        bank.setCustName("qwerty");
	        long AccNum=dao.createAccount(bank);
	        
	        Assert.assertEquals(1000,AccNum);
	        
            
        } 
} 




