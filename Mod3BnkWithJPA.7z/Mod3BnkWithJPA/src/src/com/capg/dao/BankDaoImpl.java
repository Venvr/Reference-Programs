package src.com.capg.dao;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import src.com.capg.bean.Account;
import src.com.capg.bean.Transaction;


public class BankDaoImpl implements BankDao{

private EntityManager entityManager;
	
	public BankDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public long createAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.persist(account);
		return account.getAccNo();
	}

	@Override
	public long accountBalance(Long accNo1) {
		// TODO Auto-generated method stub
		Account account = entityManager.find(Account.class,accNo1 );
		return account.getBalance();
		
	}

	@Override
	public long depositAmt(long accNo1, long depAmt) {
		// TODO Auto-generated method stub
		Account account = entityManager.find(Account.class,accNo1 );
	        long oldbal=account.getBalance();
	        long newbal=depAmt+oldbal;
	        account.setBalance(newbal);
	        entityManager.merge(account);
	       
	        
	        Transaction tran=new Transaction();
	        tran.setFromAccount(accNo1);
	        tran.setToAccount(accNo1);
	        tran.setOldBalance(oldbal);
	        tran.setNewBalance(newbal);
	        tran.setTransactionType("deposit");
	        entityManager.persist(tran);
	        
	        return newbal;
		
	}

	@Override
	public long withdrawAmt(long accNo1, long withAmt) {
		Account account = entityManager.find(Account.class,accNo1 );
        long oldbal=account.getBalance();
        long newbal=oldbal-withAmt;
        account.setBalance(newbal);
        entityManager.merge(account);
        
        Transaction tran=new Transaction();
        tran.setFromAccount(accNo1);
        tran.setToAccount(accNo1);
        tran.setOldBalance(oldbal);
        tran.setNewBalance(newbal);
        entityManager.persist(tran);
        
        return newbal;
	}

	@Override
	public long transfer(long accNo1, long accNo2, long amt) {
		  Account account = entityManager.find(Account.class, accNo1);
	        long oldbal=account.getBalance();
	        long newBal=oldbal-amt;
	        account.setBalance(newBal);
	        entityManager.merge(account);
	       
	        Transaction tran=new Transaction();
	        tran.setFromAccount(accNo1);
	        tran.setToAccount(accNo1);
	        tran.setOldBalance(oldbal);
	        tran.setNewBalance(newBal);
	        tran.setTransactionType("FDTransfer");
	        entityManager.persist(tran);
	        
	        Account account1 = entityManager.find(Account.class, accNo2);
	        long oldbal1=account1.getBalance();
	        long newBal1=oldbal+amt;
	        account1.setBalance(newBal1);
	        entityManager.merge(account1);
	       
	        Transaction tran1=new Transaction();
	        tran1.setFromAccount(accNo2);
	        tran.setToAccount(accNo2);
	        tran1.setOldBalance(oldbal1);
	        tran1.setNewBalance(newBal1);
	        tran.setTransactionType("FDTransfer");
	        entityManager.persist(tran1);
	        
		return newBal;
	}

	

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
    public List<Transaction> printTransactions() {
/*		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();*/
        TypedQuery<Transaction> tq=entityManager.createQuery("select c from Transaction c",Transaction.class);
        List<Transaction> list1=tq.getResultList();
        
        return list1;
       
    }

		
}
