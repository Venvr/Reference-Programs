package src.com.cap.usrdefExptns;

@SuppressWarnings("serial")
public class AccountNotFoundException extends RuntimeException{
	public AccountNotFoundException(final String msg)
	{
		super(msg);
	}

}
