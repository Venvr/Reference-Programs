package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;

 

public class BankDaoImp1 implements BankDao {
	 Connection conn=DBConnect.getConnection();

	@Override
	public long createAccount(BankDetails bankdetails) {

		// Connection conn= DBConnect.getConnection();
		Connection conn= DBConnect.getConnection();
        long acno=0;
        try {
            PreparedStatement stmt= conn.prepareStatement("insert into BankDatabase1 values(bankseq1.nextval,?,?,?,?,?)");
            stmt.setString(1,bankdetails.getCustName());
            stmt.setString(2, bankdetails.getCustBranch());
            stmt.setLong(3, bankdetails.getAccBal());
            stmt.setString(4, bankdetails.getAccType());
            stmt.setLong(5, bankdetails.getCustMobNum());
            int result=stmt.executeUpdate();
            if(result>0){
                 PreparedStatement stmt1= conn.prepareStatement("select bankseq1.currval from dual");
                 ResultSet rs=stmt1.executeQuery();
                 rs.next();
                  acno=rs.getLong(1);
            }
            } catch (SQLException e) {
                e.printStackTrace();
            }
      
       
        return acno ;
		    }

	@Override
	public long showDetails(long accNum) {
		
		// public long showDetails(long Acno1){
		        long accountNumber=0;
		        PreparedStatement stat;
		        try {
		            stat = conn.prepareStatement("select balance from BankDatabase1 where accountNumber=?");
		            stat.setLong(1, accNum);//Acno1
		            ResultSet rs=stat.executeQuery();
		            rs.next();
		            accountNumber=rs.getLong(1);
		            
		        } catch (SQLException e) {
		        
		            e.printStackTrace();
		        }
		      
		        return accountNumber;
		   
	}

	@Override
	public long depositDetails(long accNum, long depAcc) {
		 PreparedStatement stat, stat2;
	        long newBal = 0;
	        try {
	            stat = conn.prepareStatement("select balance from BankDatabase1 where Accountnumber=?");
	            stat.setLong(1, accNum);
	            ResultSet rs = stat.executeQuery();
	            rs.next();
	            Long oldBal=rs.getLong(1);
	            newBal =  oldBal+ depAcc;
	            stat2 = conn.prepareStatement("update BankDatabase1 set balance=? where Accountnumber=?");
	            stat2.setLong(1, newBal);
	            stat2.setLong(2, accNum);
	            int res=stat2.executeUpdate();
	            if(res>0)
                {
                   
                    PreparedStatement st2=conn.prepareStatement("insert into Transaction values(transeq.nextval,?,?,?,?,?)");
                    st2.setString(1,"DepositDetails");
                    st2.setLong(2,oldBal );
                    st2.setLong(3, newBal);
                    st2.setLong(4, accNum);
                    st2.setLong(5, accNum);
                    int result3=st2.executeUpdate();
                   
                }
	        }
	        catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        return newBal;
	    }
		@Override
	public long withdrawDetails(long accNum, long withDraw) {
		 PreparedStatement stat, stat2;
         long oldBal = 0,newBal=0;
         try {
             stat = conn.prepareStatement("select balance from BankDatabase1 where Accountnumber=?");
             stat.setLong(1, accNum);
             ResultSet rs = stat.executeQuery();
             rs.next();
             oldBal=rs.getLong(1);
            newBal = oldBal-withDraw;
             stat2 = conn.prepareStatement("update BankDatabase1 set balance=? where Accountnumber=?");
             stat2.setLong(1, newBal);
             stat2.setLong(2, accNum);
            int res= stat2.executeUpdate();
             if(res>0)
             {
                
                 PreparedStatement st2=conn.prepareStatement("insert into Transaction values(transeq.nextval,?,?,?,?,?)");
                 st2.setString(1,"withdraw");
                 st2.setLong(2,oldBal );
                 st2.setLong(3,newBal);
                 st2.setLong(4, accNum);
                 st2.setLong(5, accNum);
                 int result3=st2.executeUpdate();
                
             }
         }
         catch (SQLException e)
         {
             e.printStackTrace();
         }
         return newBal;
 }

	@Override
	public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
		 PreparedStatement stat, stat2,stat3,stat4;
	        long oldBal = 0,newBal = 0;
	        long oldBal1 = 0,newBal1 = 0;
	        try {
	            stat = conn.prepareStatement("select balance from BankDatabase1 where Accountnumber=?");
	            stat.setLong(1, accNum4);
	            ResultSet rs = stat.executeQuery();
	            rs.next();
	            oldBal=rs.getLong(1);
	            newBal =oldBal -fundTrans;
	            stat2 = conn.prepareStatement("update BankDatabase1 set balance=? where Accountnumber=?");
	            stat2.setLong(1, newBal);
	            stat2.setLong(2, accNum4);
	            int res=stat2.executeUpdate();
	            if(res>0)
	             {
	                
	                 PreparedStatement st2=conn.prepareStatement("insert into Transaction values(transeq.nextval,?,?,?,?,?)");
	                 st2.setString(1,"fund transfer");
	                 st2.setLong(2,oldBal );
	                 st2.setLong(3,newBal);
	                 st2.setLong(4, accNum4);
	                 st2.setLong(5, accNum5);
	                 int result3=st2.executeUpdate();
	                
	             }
	            stat3 = conn.prepareStatement("select balance from BankDatabase1 where Accountnumber=?");
	            stat3.setLong(1, accNum5);
	            ResultSet rs2 = stat3.executeQuery();
	            rs2.next();
	            oldBal1= rs2.getLong(1);
	            newBal1 =oldBal1+fundTrans;
	            stat4 = conn.prepareStatement("update BankDatabase1 set balance=? where Accountnumber=?");
	            stat4.setLong(1, newBal1);
	            stat4.setLong(2, accNum5);
	            stat4.executeUpdate();
	            if(res>0)
	             {
	                
	                 PreparedStatement st2=conn.prepareStatement("insert into Transaction values(transeq.nextval,?,?,?,?,?)");
	                 st2.setString(1,"fund transfer");
	                 st2.setLong(2,oldBal1 );
	                 st2.setLong(3,newBal1);
	                 st2.setLong(4, accNum4);
	                 st2.setLong(5, accNum5);
	                 int result3=st2.executeUpdate();
	                
	             }
	        }
	        catch (SQLException e)
	        {
	            e.printStackTrace();
	        }
	        return newBal;
	    
	}

	@Override
	public void printTransactions() {
		BankTransactions tran=new BankTransactions();
		
		try {
			Connection conn=DBConnect.getConnection();
			PreparedStatement stat = conn.prepareStatement("select * from Transaction");
			 ResultSet rs = stat.executeQuery();
			 while(rs.next()){
			    long transId=rs.getLong(1);
			    String transType=rs.getString(2);
			    long transOldBal=rs.getLong(3);
			    long transNewBal=rs.getLong(4);
			    long fromAcc=rs.getLong(5);
			    long toAcc=rs.getLong(6);
			    tran.setTransId(transId);
			    tran.setTransType(transType);
			    tran.setTransOldBal(transOldBal);
			    tran.setTransNewBal(transNewBal);
			    tran.setFromAcc(fromAcc);
			    tran.setToAcc(toAcc);
			    System.out.println(tran);
			 }
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	
	}

	


}


