package com.cap.bean;

public class BankTransactions {
    private long transId;
    private String transType;
    private long transOldBal;
    private long transNewBal;
    private long fromAcc;
    private long toAcc;
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public long getTransOldBal() {
		return transOldBal;
	}
	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}
	public long getTransNewBal() {
		return transNewBal;
	}
	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}
	public long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public long getToAcc() {
		return toAcc;
	}
	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}
	@Override
	public String toString() {
		return "BankTransactions [transId=" + transId + ", transType=" + transType + ", transOldBal=" + transOldBal
				+ ", transNewBal=" + transNewBal + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + "]";
	}
    
//setter and getters
    
  

 

  

 


    

}